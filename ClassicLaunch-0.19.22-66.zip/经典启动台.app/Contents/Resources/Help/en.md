# Classic Launch Help

Classic Launch restores the grid, folders, and drag-to-organize experience of the classic macOS launcher. It stores only its own layout configuration and never moves or modifies actual app files.

## Quick Start

- Click an app icon to minimize the launcher with the system animation, then open the app.
- Type in the search field to filter apps.
- Click an empty area in the parent window to minimize the launcher with the system animation.
- Use the launcher menu to fill the current desktop or return to windowed mode. No new desktop is created.
- Press Escape to close a folder first, then minimize the launcher.

## Selection and Grouping

- Command-click an app or website to add it; Command-click a selected item to remove it.
- Drag a selection rectangle in an empty area to select several apps and websites.
- Command-drag a selection rectangle to toggle the items inside it.
- Right-click a selected item to create a folder or move the selection into an existing folder.
- When items are selected, the first blank-area click only clears the selection; click again to exit according to the setting.
- Move Forward and Move Backward appear only for a single app.

## Folders

- With Command-Drag to Organize into Folders enabled, hold Command and drag an app or website onto another app or website to create a folder.
- With that setting enabled, hold Command and drag an app or website onto an existing folder to add it.
- A main-grid drag without Command only reorders items and never creates or enters a folder.
- When Command-drag reaches a valid target, the target app, website, or folder enlarges with a spring animation; release immediately to complete the action without an additional dwell.
- Drag apps and websites inside a folder to reorder their mixed sequence.
- Dissolving a folder returns apps and websites to the main grid in their folder order.
- Right-click a folder and choose Dissolve Folder to remove the virtual folder and release its apps in their existing order at the folder's position. Command-Z can undo the change.
- Click outside the folder panel to close it.
- Use a trackpad or mouse wheel when a folder contains more than one screen.

## Keyboard

- Arrow keys move focus and wrap from the last item to the first.
- Return opens the focused app or folder.
- Command-F focuses search.
- Command-Space toggles selection for the focused app.
- Command-Z undoes the last change.
- Shift-Command-Z redoes it.
- Command-M minimizes the launcher.
- The system full-screen shortcut is disabled to prevent creating another Space.
- Command-? opens this help document.

## Context Menus

Context menus adapt to the clicked item and selection count. App, folder, subfolder, and empty-area menus show only relevant commands. Show in Finder and forward/backward movement appear only for a single app.

The Help menu contains Help Document, About Us, and the official macOS feedback command. Help Document opens a separate window and loads the Markdown file for the current language; About Us opens a centered about window.

## Settings and VIP

The Standard tab contains language, general settings, and app scanning. General settings work as follows:

- Exit Launcher When Clicking Empty Space: when off, an empty-space click only clears the current selection.
- Keep Launcher Visible After Opening Apps: off by default; when off, the launcher minimizes with the system animation before the target app opens.
- Folders First: keeps folders ahead of apps when sorting.
- Disable Drag Reordering: prevents mouse-drag reordering, while single items can still move from the context menu.
- Command-Drag to Organize into Folders: when enabled, regular dragging only reorders; hold Command while dragging to create a folder or add an item to one. When disabled, every main-grid drag only reorders.
- Show Hints: controls the operation hints shown near the bottom of the interface.
- Popup Animations: off by default; when enabled, folders open and close with a smooth fade and subtle scale transition. Reduce Motion keeps only the fade.
- Open in Full Screen: takes effect on the next launch, fills only the current desktop, and does not create a new Space.

The Lifetime VIP tab contains the one-time purchase unlock, Quick Launch Groups, and theme settings.

### Menu Bar Quick Launcher

Use the grid icon in the system menu bar to open frequently used items even when Classic Launch is not in front. Right-click an app, folder, or existing Quick Launch Group and choose Pin to Menu Bar. The folder menu at the top always keeps Home first and lets you switch directly between any folders. Search is at the bottom. Open Full Launcher first closes the panel; it does nothing else when the main window is already frontmost, and switches to it only when it is behind, minimized, or on another Space.

- The Menu Bar Quick Launcher is a standard feature with no limit on pinned items, item types, or search.
- Open Settings → Standard → Menu Bar Quick Launcher to reorder or remove items, or hide the menu bar icon.
- Pinning changes only Classic Launch references. It never moves or deletes actual apps and does not alter the main grid or folder layout.
- The panel supports Tab, arrow keys, Return, and Escape, with accessibility labels for every item.

### AI-Assisted Organization

When the main grid contains many standalone apps, open Settings → Lifetime VIP → AI-Assisted Organization and export the Markdown instructions. The file contains only app display names, temporary references, a privacy notice, and a prompt template. It excludes app paths, bundle identifiers, usage history, existing folders, shortcuts, and the full layout.

1. Click Export AI Grouping Instructions and review the app names in the Markdown file.
2. Choose any AI chat or local model yourself and provide the Markdown content. Once shared, the privacy policy of that AI service applies.
3. Ask the AI to return only the JSON defined in the instructions and save the response as a `.json` file.
4. Click Import AI Grouping Result. After validation, review the folders to be created and the apps to be moved.
5. The layout changes only after you click Apply Grouping. A local backup is created first, and Command-Z can undo the change.

AI grouping processes only standalone apps that were in the main grid at export time. Existing folders, Quick Launch Groups, layout profiles, global shortcuts, usage statistics, and settings are preserved. If an app is uninstalled or manually moved into a folder after export, importing skips it instead of overwriting the newer manual organization.

Classic Launch does not connect to an AI service, upload files automatically, or store an AI API key. The importer rejects unsupported versions, unknown fields, duplicated or missing app references, and results that do not match a request exported on this Mac. Closing the preview never changes the layout.

### Advanced Themes

- Gradient: customize the start and end colors and choose diagonal, vertical, horizontal, or reverse-diagonal direction.
- Background Image: the selected image is copied into Classic Launch data storage, so moving the original file does not break the theme.
- Image Blur: applies only to the background image and helps reduce visual distraction.
- Icon Size and Spacing: affect the main launcher, folder panels, and launch groups.
- Font: choose System, Rounded, Serif, or Monospaced and adjust app-label size.
- Reset Theme: removes the background image and restores the default gradient, sizing, spacing, and font.

### Website Shortcuts

Lifetime VIP can add a website from Settings → Lifetime VIP → Website Shortcuts or by right-clicking an empty area of the main grid. Enter a name and an HTTP/HTTPS address. The website becomes a searchable and draggable grid item that can be placed in folders, pinned to the menu bar, or included in a Quick Launch Group with apps. HTTPS is added automatically when the protocol is omitted.

Website icons are generated locally from the domain, so Classic Launch does not send your saved-site list to a third-party favicon service. Deleting a shortcut removes only the local reference and does not affect browser bookmarks. Non-web protocols such as `file:` and `javascript:` are rejected.

### Quick Launch Groups

1. Open Settings → Lifetime VIP.
2. Click New Launch Group under Quick Launch Groups.
3. Enter a group name and select the apps and websites to open together.
4. After saving, the group appears on the main launcher as a distinct icon with a play badge.
5. Click the group icon to open every item. Classic Launch minimizes only once.

Right-click a group icon to launch, edit, move, or delete it. Right-click an app, an app inside a folder, or a website to add it to an existing launch group.

A launch group stores app and website references. The same item can remain in its original location and belong to several launch groups. Deleting a group removes only the launch rule and never changes actual apps or browser data.

### Advanced Shortcuts

- Open Settings → Lifetime VIP → Advanced Shortcuts to assign global shortcuts to folders, app launch groups, and layout profiles.
- A folder shortcut shows the launcher and opens that folder. A group shortcut launches all apps in the group. A layout-profile shortcut restores the saved arrangement.
- Enter a name under Layout Profiles and click Save Current Layout to preserve the current grid, folders, and ordering as a switchable profile.
- Shortcuts must contain Command, Option, Control, or Shift so ordinary keys never interfere with typing in other apps.
- A shortcut cannot be assigned twice. The settings page reports combinations reserved by macOS or another app.
- Global shortcuts are registered only while Lifetime VIP is active. Turning off the Debug VIP override disables them immediately without deleting their configuration.

Changing the language restarts the app so the interface, context menus, and menu bar all use the selected language.

## Troubleshooting

**The launched app appears behind another window.**  
Classic Launch now minimizes with the standard macOS animation before activating the target app. It stays visible only when Keep Launcher Visible After Opening Apps is enabled. If the target app has no visible window, use its Window menu to open one.

**Why are there no scroll bars?**  
This is intentional. A down arrow indicates more content, and trackpad or mouse-wheel scrolling remains available.

**Does changing the layout affect actual apps?**  
No. Folder deletion, sorting, and layout recovery change only Classic Launch configuration.

**When does a newly installed app appear?**  
Classic Launch scans at startup and watches the system application folders. A completed installation is normally added to the main grid automatically, and activating the launcher performs a throttled fallback check without requiring a manual rescan.
