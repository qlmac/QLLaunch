/* 目录和说明均来自文稿数据；翻译只改文稿与界面语言资源，不改此脚本。 */
(() => {
  'use strict';
  const documentData = JSON.parse(document.getElementById('help-data').textContent);
  const labels = documentData.labels;
  const search = document.getElementById('search');
  const clear = document.getElementById('clear-search');
  const navigation = document.getElementById('navigation');
  const content = document.getElementById('content');
  let selected = documentData.sections[0]?.id;
  let timer;
  const normalize = text => text.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase(document.documentElement.lang);
  const node = (tag, className, text) => {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  };
  document.getElementById('document-title').textContent = documentData.title;
  search.placeholder = labels.search;
  search.setAttribute('aria-label', labels.search);
  clear.setAttribute('aria-label', labels.clearSearch);
  navigation.setAttribute('aria-label', labels.navigation);

  // 语言清单由发布工具生成。界面名称与地址不依赖脚本内写死的语言列表。
  function configureLanguages() {
    const website = documentData.website;
    if (!website) return false;
    const picker = document.getElementById('help-language');
    document.getElementById('language-box').hidden = false;
    picker.setAttribute('aria-label', website.languageLabel);
    for (const language of website.languages) {
      const option = node('option', '', language.name);
      option.value = language.id;
      option.lang = language.id;
      picker.append(option);
    }
    picker.value = website.currentLanguage;
    const storageKey = 'classiclaunch.help.language';
    const remember = id => { try { localStorage.setItem(storageKey, id); } catch (_) {} };
    const match = preference => {
      if (!preference) return undefined;
      const exact = website.languages.find(item => item.id.toLowerCase() === preference.toLowerCase());
      if (exact) return exact;
      // 使用语言与文字体系匹配地区变体：例如 zh-TW 对应繁体，en-GB 对应英文。
      try {
        const requested = new Intl.Locale(preference).maximize();
        return website.languages.find(item => {
          const available = new Intl.Locale(item.id).maximize();
          return available.language === requested.language && available.script === requested.script;
        });
      } catch (_) { return undefined; }
    };
    picker.addEventListener('change', () => {
      const language = website.languages.find(item => item.id === picker.value);
      if (!language) return;
      remember(language.id);
      window.location.assign(language.href);
    });
    const requested = match(new URLSearchParams(window.location.search).get('lang'));
    if (requested) remember(requested.id);
    if (website.automaticSelection || requested) {
      let remembered;
      try { remembered = match(localStorage.getItem(storageKey)); } catch (_) {}
      const preferred = requested || remembered
        || (navigator.languages || [navigator.language]).map(match).find(Boolean)
        || match(website.fallbackLanguage) || match(website.defaultLanguage);
      if (preferred && preferred.id !== website.currentLanguage) {
        window.location.replace(preferred.href);
        return true;
      }
    } else {
      // 直接打开某种语言的固定链接，也视为主动选择；首页仍尊重浏览器偏好。
      remember(website.currentLanguage);
    }
    return false;
  }

  function show(id, moveFocus = false) {
    selected = id;
    search.value = '';
    clear.hidden = true;
    renderNavigation();
    renderArticle();
    if (moveFocus) content.focus();
  }

  function renderNavigation() {
    navigation.replaceChildren();
    for (const section of documentData.sections) {
      const group = node('div', 'nav-group');
      const button = node('button', 'nav-section', section.title);
      button.dataset.id = section.id;
      const ownsSelection = selected === section.id || section.topics.some(topic => topic.id === selected);
      if (selected === section.id) button.classList.add('active');
      button.setAttribute('aria-expanded', String(ownsSelection));
      if (selected === section.id) button.setAttribute('aria-current', 'page');
      button.addEventListener('click', () => show(section.id));
      group.append(button);
      if (ownsSelection) {
        for (const topic of section.topics) {
          const item = node('button', 'nav-topic', topic.title);
          item.dataset.id = topic.id;
          if (selected === topic.id) {
            item.classList.add('active');
            item.setAttribute('aria-current', 'page');
          }
          item.addEventListener('click', () => show(topic.id));
          group.append(item);
        }
      }
      navigation.append(group);
    }
  }

  function renderArticle() {
    content.replaceChildren();
    const article = node('article', 'article');
    for (const section of documentData.sections) {
      const topic = section.topics.find(item => item.id === selected);
      if (section.id !== selected && !topic) continue;
      if (topic) article.append(node('div', 'breadcrumb', section.title));
      article.append(node('h2', '', topic ? topic.title : section.title));
      if (!topic && section === documentData.sections[0] && documentData.introduction) {
        const intro = node('div', 'intro');
        intro.innerHTML = documentData.introduction;
        article.append(intro);
      }
      const body = node('div', 'body');
      body.innerHTML = topic ? topic.html : section.html;
      article.append(body);
      if (!topic) {
        for (const item of section.topics) {
          const card = node('section', 'topic-card');
          const heading = node('h3', '');
          const link = node('button', '', item.title);
          link.addEventListener('click', () => show(item.id, true));
          heading.append(link);
          const description = node('div', 'body');
          description.innerHTML = item.html;
          card.append(heading, description);
          article.append(card);
        }
      }
    }
    content.append(article);
    content.scrollTop = 0;
  }

  function renderSearch() {
    const query = normalize(search.value.trim());
    clear.hidden = !query;
    if (!query) { renderArticle(); return; }
    const results = [];
    for (const section of documentData.sections) {
      if (normalize(section.title + ' ' + section.text).includes(query)) {
        results.push({ id:section.id, title:section.title, text:section.text, category:'' });
      }
      for (const topic of section.topics) {
        if (normalize(section.title + ' ' + topic.title + ' ' + topic.text).includes(query)) {
          results.push({ ...topic, category:section.title });
        }
      }
    }
    content.replaceChildren();
    const article = node('article', 'article');
    article.append(node('h2', '', labels.searchResults));
    if (!results.length) article.append(node('p', 'empty', labels.noResults));
    for (const result of results) {
      const item = node('button', 'search-result');
      if (result.category) item.append(node('small', '', result.category));
      item.append(node('strong', '', result.title));
      // 搜索输入只作为纯文本，不能通过关键字插入 HTML 或执行脚本。
      if (result.text) {
        const position = normalize(result.text).indexOf(query);
        const start = Math.max(0, position - 35);
        const excerpt = result.text.slice(start, start + 150);
        item.append(node('p', '', (start ? '…' : '') + excerpt + (start + 150 < result.text.length ? '…' : '')));
      }
      item.addEventListener('click', () => show(result.id, true));
      article.append(item);
    }
    content.append(article);
    content.scrollTop = 0;
  }

  search.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(renderSearch, 100); });
  clear.addEventListener('click', () => { clearTimeout(timer); search.value = ''; renderSearch(); search.focus(); });
  window.helpFocusSearch = () => { search.focus(); search.select(); };
  document.addEventListener('keydown', event => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'f') {
      event.preventDefault(); window.helpFocusSearch();
    }
  });
  if (configureLanguages()) return;
  renderNavigation();
  renderArticle();
})();
