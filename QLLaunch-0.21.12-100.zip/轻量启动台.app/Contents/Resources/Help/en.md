# QL Launch Help

QL Launch saves only your layout configuration. It never moves or modifies actual app files.

## 1) Quick Start
- Open: click an app or website, or press `Return` on the highlighted item.
- Search: enter a keyword, pinyin initials, or full pinyin in the search box.
- Exit: press `Esc` to close the topmost child window first, then minimize the launcher.
- Multi-select: `⌘ + click`, or drag a selection box across an empty area.
- Organize: enable **Hold ⌘ to organize** in Settings, then use `⌘ + drag` to create or add items to a folder.
- Reorder: drag icons directly to change their order.
- Click empty area: clear a multi-selection, then close child windows one layer at a time before exiting the launcher.

## 2) Context Menu Actions
- Empty area: New Folder / Rebuild App Index / Settings / Fullscreen / Minimize.
- App or website icon: Move into Folder / Add to Launch Group / Pin to Menu Bar; websites can also be edited or removed.
- Folder: Rename / Dissolve / Pin to Menu Bar.
- Available actions change according to the item you right-click.

## 3) Menu Bar Quick Launcher
- Open custom and frequently used items without switching to the main window.
- Switch between your folders at the top and drag icons to reorder them.
- Dragging to the removal area clears only the shortcut icon; it does not delete the actual app.

## 4) Free and Lifetime VIP Features
- Free: all essential launcher features remain free to use.
- Lifetime VIP: Smart Organize, website shortcuts, launch groups, themes, layout profiles, and shortcuts.

## 5) AI Data Transfer and Security
- Your API key is encrypted in this Mac's system Keychain and is never stored in plaintext.
- When making a request, the API key is sent as a credential to your selected AI provider. Make sure you trust the server before using a custom endpoint. Local Ollama does not require a real key.
- Remote endpoints must use HTTPS, and cross-host redirects are blocked.
- AI receives only the display names and temporary IDs of apps and existing folders. Paths, Bundle IDs, real UUIDs, website URLs, usage history, and the full layout are not uploaded. Selected website and system-app organization happens locally.
- You can preview a plan before applying it. Back up your layout first; changes can be undone.

## 6) FAQ
- New app not shown: reactivate QL Launch. If it is still missing, click **Rebuild App Index** in Settings.
- Will QL Launch delete or modify real apps? No. It changes only their order and organization inside QL Launch.
- No visible scroll bar? This is part of the simplified design; use the mouse wheel or trackpad to scroll.
- AI organization failed: check the API key, network, endpoint, and model. Your layout remains unchanged until a valid plan is generated.
